import { ModuleWithProviders } from '@angular/core';
export * from './hide-keyboard.directive';
export declare class HideKeyboardModule {
    static forRoot(): ModuleWithProviders;
}
